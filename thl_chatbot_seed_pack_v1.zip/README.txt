THL Chatbot Seed Pack v1

Bộ seed data khởi đầu để nạp vào chatbot tra mã.

Thứ tự ưu tiên nạp:
1. brand_policy
2. master_catalog
3. slang_map
4. question_tree
5. conversation_examples
6. application_fitment
7. symptom_rules
8. confusion_rules
9. equivalent_map
